/*
 * @Author: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
 * @Date: 2023-09-13 17:02:39
 * @LastEditors: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
 * @LastEditTime: 2023-10-16 09:34:34
 * @FilePath: \lighting_led\main.c
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
 /*
  *                        _oo0oo_
  *                       o8888888o
  *                       88" . "88
  *                       (| -_- |)
  *                       0\  =  /0
  *                     ___/`---'\___
  *                   .' \\|     |// '.
  *                  / \\|||  :  |||// \
  *                 / _||||| -:- |||||- \
  *                |   | \\\  - /// |   |
  *                | \_|  ''\---/''  |_/ |
  *                \  .-\__  '-'  ___/-. /
  *              ___'. .'  /--.--\  `. .'___
  *           ."" '<  `.___\_<|>_/___.' >' "".
  *          | | :  `- \`.;`\ _ /`;.`/ - ` : | |
  *          \  \ `_.   \_ __\ /__ _/   .-` /  /
  *      =====`-.____`.___ \_____/___.-`___.-'=====
  *                        `=---='
  *
  *
  *      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  *
  *            佛祖保佑     永不宕机     永无BUG
  */


#include <REGF51RC.H>
#include"LCD1602.h"
#include"timer.h"
#include"key.h"
#include"nixie.h"
#include"uart.h"
#include"delay.h"

static long t, sta = 0;
volatile unsigned char sc = 0, mn = 0, hr = 0;
volatile unsigned char ima[8] = { 0 },cpy[8] = { 0 }, l = sizeof(ima),k=0,status=0;

sbit scl = P3 ^ 6;
sbit ser = P3 ^ 4;
sbit rcl = P3 ^ 5;


void ItrpIni() {
	EA = 1;
}


void timer0() interrupt 1
{
	static unsigned int cnt = 0,i=0,temp=0;
	TH0 = (t >> 8) & 0xff;
	TL0 = t & 0x00ff;

	if (status&&(++cnt==8)) {
		UartSend(1);
		status = 0;
	}


	// P2_0 = 1;
}

void UartRcv(void) interrupt 4
{
	unsigned char dt,i;
	if (RI == 1) {
		dt = SBUF;
		ima[k] = dt;
		k++;
		if (k == 8) {
			for (i = 0;i < 8;i++) {
				cpy[i] = ima[i];
			}
			k = 0;
			UartSend(1);

		}
		RI = 0;
	}
}

void _595_Write(unsigned char byte) {
	unsigned char i;
	
	for (i = 0;i < 8;i++) {
		ser = byte & (0x80 >> i);
		scl = 1;
		scl = 0;
	}
	rcl = 1;
	rcl = 0;
	
}

void ShowPic(unsigned char image[8]) {
	unsigned char i;
	for (i = 0; i < 8; i++)
	{
		P0 = 0xff;
		_595_Write(image[i]);
		P0 = ~(0x80 >> i);
		Delay1ms();
	}
	
}

void main() {

	ItrpIni();
	UartInit();


	//t = timer0Init(0x01, 5, 1);
	// while (1)
	// {
	// 	nxShowDig(0, hr, 2);
	// 	nxShowDig(3, mn, 2);
	// 	nxShowDig(6, sc, 2);
	// 	UartSend(sc);
	// }

	//ItrpIni();
	P0 = 0xa0;
	scl = rcl = 0;
	while (1)
	{
		
		ShowPic(cpy);
	}
	
}
