#ifndef __n_h__
#define __n_h__

void nxShowDig(char pos, char num, char width);

#endif