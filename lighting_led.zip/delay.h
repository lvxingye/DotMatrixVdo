#ifndef __d_h__
#define __d_h__

void Delay1ms(void);
void Delay20ms(void);
void Delay50ms(void);

#endif