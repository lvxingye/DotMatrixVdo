#ifndef __k_h__
#define __k_h__

unsigned char GetMatrixNum(void);

#endif