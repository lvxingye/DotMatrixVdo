#include <REGF51RC.H>

unsigned char GetMatrixNum(void) {
	unsigned char sta = 0x10, i = 0x04;
	while(i--){
		P1 = ~(sta?sta:(sta=0x01));
		sta <<= 1;
		if (~(P1 & 0x0f)) {
			Delay20ms();
			switch (~P1 & 0x0f)
			{
			case 0x01:
				return i * 4 + 4;
			case 0x02:
				return i * 4 + 3;
			case 0x04:
				return i * 4 + 2;
			case 0x08:
				return i * 4 + 1;
			}
		}
	}
	return 0;
}
