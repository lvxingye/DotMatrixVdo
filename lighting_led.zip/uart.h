#ifndef __u_h__
#define __u_h__

void UartInit(void);
void UartSend(unsigned char byte);
void uart_rcv(void);

#endif