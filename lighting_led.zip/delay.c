#include <REGF51RC.H>

void Delay1ms(void)	//@11.0592MHz
{
	unsigned char data i, j;

	i = 2;
	j = 199;
	do
	{
		while (--j);
	} while (--i);
}

void Delay20ms(void)	//@11.0592MHz
{
	unsigned char data i, j;

	i = 36;
	j = 217;
	do
	{
		while (--j);
	} while (--i);
}

void Delay50ms(void)	//@11.0592MHz
{
	unsigned char data i, j;

	i = 90;
	j = 163;
	do
	{
		while (--j);
	} while (--i);
}
