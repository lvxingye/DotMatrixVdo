/*
 * @Author: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
 * @Date: 2023-10-04 00:34:30
 * @LastEditors: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
 * @LastEditTime: 2023-10-09 11:16:04
 * @FilePath: \lighting_led\timer.c
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
#include <REGF51RC.H>

unsigned long timer1Init(char mode, unsigned long time,unsigned char enableItpr)
{
	TMOD &= 0x0f;
	TMOD |= (mode & 0x03) << 4;

	time = (time * 1000 / 1.0909090909);
	time = 0xffff - time + 1;
	TH1 = (time >> 8) & 0xff;
	TL1 = time & 0x00ff;	
	ET1 = enableItpr;
	TR1 = 1;
	return time;
}

//1.0850694444us
unsigned long timer0Init(char mode, unsigned long time,unsigned char enableItpr)
{
	TMOD &= 0xf0;
	TMOD |= mode & 0x03;

	time = (time * 1000 / 1.0850694444);
	time = 0xffff - time + 1;
	TH0 = (time >> 8) & 0xff;
	TL0 = time & 0x00ff;	
	ET0 = enableItpr;
	TR0 = 1;
	return time;
}
