#include <REGF51RC.H>

char nixie[8] = { 0xe3,0xe7,0xeb,0xef,0xf3,0xf7,0xfb,0xff };
char digit[10] = { 0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f };

void nxShowDig(char pos, char num, char width) {
	unsigned char i = width;
	P0 = 0;
	while (i) {
		if((8 - pos - i)>=0){
			P0 = 0;
			P2 = nixie[8 - pos - i];
			P0 = digit[num % 10];
			Delay1ms();
			Delay1ms();
		}
		num /= 10;
		i--;
	}
}
