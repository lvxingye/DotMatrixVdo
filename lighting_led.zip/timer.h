#ifndef __t_h__
#define __t_h__

unsigned long timer0Init(char mode, unsigned long time,unsigned char enableItpr);
unsigned long timer1Init(char mode, unsigned long time,unsigned char enableItpr);

#endif